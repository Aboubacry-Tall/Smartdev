# pylint: disable=import-error

from odoo import _, api, models
from odoo.exceptions import AccessError

from lxml import etree


class HelpdeskTicket(models.Model):
    _inherit = "helpdesk.ticket"

    def _dg_read_all_active(self) -> bool:
        return (not self.env.su) and (
            self.env.user.has_group("access_management.group_dg_read_all")
            or self.env.user.has_group("access_management.group_audit")
        )

    def _dev_no_create_delete(self) -> bool:
        return (not self.env.su) and self.env.user.has_group("access_management.group_dev")

    def _support_n1_no_create_delete(self) -> bool:
        return (not self.env.su) and self.env.user.has_group("access_management.group_support_n1")

    def _support_n2_no_create_delete(self) -> bool:
        return (not self.env.su) and self.env.user.has_group("access_management.group_support_n2")

    @api.model
    def get_view(self, view_id=None, view_type="form", **options):
        result = super().get_view(view_id=view_id, view_type=view_type, **options)

        if self._dg_read_all_active() and view_type in {"list", "kanban", "form"}:
            node = etree.fromstring(result["arch"])
            node.set("create", "0")
            node.set("edit", "0")
            node.set("delete", "0")
            result["arch"] = etree.tostring(node, encoding="unicode")
        elif (self._dev_no_create_delete() or self._support_n1_no_create_delete() or self._support_n2_no_create_delete()) and view_type in {"list", "kanban", "form"}:
            node = etree.fromstring(result["arch"])
            node.set("create", "0")
            node.set("delete", "0")
            result["arch"] = etree.tostring(node, encoding="unicode")

        return result

    @api.model_create_multi
    def create(self, vals_list):
        if self._dg_read_all_active() or self._dev_no_create_delete() or self._support_n1_no_create_delete() or self._support_n2_no_create_delete():
            raise AccessError(_("Vous n'êtes pas autorisé à créer des tickets helpdesk."))
        return super().create(vals_list)

    def write(self, vals):
        if self._dg_read_all_active():
            raise AccessError(_("Vous n'êtes pas autorisé à modifier des tickets helpdesk."))
        return super().write(vals)

    def unlink(self):
        if self._dg_read_all_active():
            raise AccessError(_("Vous n'êtes pas autorisé à supprimer des tickets helpdesk."))
        if self._dev_no_create_delete() or self._support_n1_no_create_delete() or self._support_n2_no_create_delete():
            raise AccessError(_("Vous n'êtes pas autorisé à supprimer des tickets helpdesk."))
        return super().unlink()
